# pinguimgame

Ficheiros:

character.png
Pinguim_Sofia_Graça_77727.html
screen.png
GameOver.jpg
life.jpg
peixes.png
winner.jpg

Tentei fazer 3 ficheiros: .html .js .css mas os link's depois não funcionam.